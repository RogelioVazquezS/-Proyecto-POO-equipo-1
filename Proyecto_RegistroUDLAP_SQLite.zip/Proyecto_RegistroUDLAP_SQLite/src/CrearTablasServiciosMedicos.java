public class CrearTablasServiciosMedicos {
    public static void main(String[] args) {
        System.out.println("La tabla debe hacerse desde SQL directamente.");
    }
}
